import 'package:flutter/material.dart';

class ApplyScreen extends StatefulWidget {
  const ApplyScreen({super.key});

  @override
  State<ApplyScreen> createState() => _ApplyScreenState();
}

class _ApplyScreenState extends State<ApplyScreen> {

  // CONTROLLERS - allow us to input/change the values in the input fields without modifying the whole widget
  final TextEditingController companyNumberController =
      TextEditingController();

  final TextEditingController recommenderController =
      TextEditingController();

  final TextEditingController approverController =
      TextEditingController();

  // DROPDOWN VALUE
  String? selectedLeaveType;

  // DATES
  DateTime? fromDate;
  DateTime? toDate;

  // DATE PICKER FUNCTION
  Future<void> pickDate(BuildContext context, bool isFromDate) async {

    DateTime initialDate = DateTime.now();

    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: initialDate,
      firstDate: DateTime(2024),
      lastDate: DateTime(2030),
    );

    if (picked != null) {
      setState(() {

        if (isFromDate) {
          fromDate = picked;
        } else {
          toDate = picked;
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(

      backgroundColor: Colors.white,

      appBar: AppBar(
        backgroundColor: const Color(0xFF041553),

        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back,
            color: Colors.white,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        ),

        title: const Text(
          'Apply for Leave',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),

      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),

        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            const SizedBox(height: 20),

            // Company number
            const Text(
              'Company Number',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w500,
              ),
            ),

            const SizedBox(height: 10),

            TextField(
              controller: companyNumberController,

              decoration: InputDecoration(
                hintText: 'Enter Company Number',

                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),

            const SizedBox(height: 25),

            // LEAVE TYPE
            const Text(
              'Leave Type',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w500,
              ),
            ),

            const SizedBox(height: 10),

            DropdownButtonFormField<String>(
              initialValue: selectedLeaveType,

              decoration: InputDecoration(
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),

              hint: const Text('Select Leave Type'),

              items: const [

                DropdownMenuItem(
                  value: 'Casual Leave',
                  child: Text('Casual Leave'),
                ),

                DropdownMenuItem(
                  value: 'Sick Leave',
                  child: Text('Sick Leave'),
                ),

                DropdownMenuItem(
                  value: 'Vacation Leave',
                  child: Text('Vacation Leave'),
                ),
              ],

              onChanged: (value) {
                setState(() {
                  selectedLeaveType = value;
                });
              },
            ),

            const SizedBox(height: 25),

            // FROM DATE
            const Text(
              'From',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w500,
              ),
            ),

            const SizedBox(height: 10),

            GestureDetector(
              onTap: () {
                pickDate(context, true);
              },

              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 18,
                ),

                decoration: BoxDecoration(
                  border: Border.all(
                    color: Colors.grey,
                  ),

                  borderRadius: BorderRadius.circular(12),
                ),

                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [

                    Text(
                      fromDate == null
                          ? 'Select Date'
                          : '${fromDate!.day}/${fromDate!.month}/${fromDate!.year}',
                    ),

                    const Icon(Icons.calendar_month),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 25),

            // TO DATE
            const Text(
              'To',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w500,
              ),
            ),

            const SizedBox(height: 10),

            GestureDetector(
              onTap: () {
                pickDate(context, false);
              },

              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 18,
                ),

                decoration: BoxDecoration(
                  border: Border.all(
                    color: Colors.grey,
                  ),

                  borderRadius: BorderRadius.circular(12),
                ),

                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [

                    Text(
                      toDate == null
                          ? 'Select Date'
                          : '${toDate!.day}/${toDate!.month}/${toDate!.year}',
                    ),

                    const Icon(Icons.calendar_month),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 25),

            // RECOMMENDER
            const Text(
              'Recommender',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w500,
              ),
            ),

            const SizedBox(height: 10),

            DropdownButtonFormField<String>(

              decoration: InputDecoration(
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),

              hint: const Text('Select Recommender'),

              items: const [

                DropdownMenuItem(
                  value: 'Manager 1',
                  child: Text('Manager 1'),
                ),

                DropdownMenuItem(
                  value: 'Manager 2',
                  child: Text('Manager 2'),
                ),
              ],

              onChanged: (value) {},
            ),

            const SizedBox(height: 25),

            // APPROVER
            const Text(
              'Approver',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w500,
              ),
            ),

            const SizedBox(height: 10),

            DropdownButtonFormField<String>(

              decoration: InputDecoration(
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),

              hint: const Text('Select Approver'),

              items: const [

                DropdownMenuItem(
                  value: 'HR 1',
                  child: Text('HR 1'),
                ),

                DropdownMenuItem(
                  value: 'HR 2',
                  child: Text('HR 2'),
                ),
              ],

              onChanged: (value) {},
            ),

            const SizedBox(height: 40),

            // Send BUTTON
            Center(
              child: SizedBox(
                width: 180,
                height: 55,

                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF041553),

                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                  ),

                  onPressed: () {

                  },

                  child: const Text(
                    'Send',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),
          ],
        
        ),
      ),
    );
  }
}

