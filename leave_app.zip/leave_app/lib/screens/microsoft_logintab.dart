import 'package:flutter/material.dart';

class MicrosoftLoginTab extends StatelessWidget {
  const MicrosoftLoginTab({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Icon(
          Icons.business,
          size: 80,
          color: Color(0xFF041553),
        ),

        const SizedBox(height: 20),

        const Text(
          'Microsoft Sign-In',
          style: TextStyle(
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),

        const SizedBox(height: 10),

        const Text(
          'Coming Soon',
          style: TextStyle(
            color: Colors.grey,
          ),
        ),

        const SizedBox(height: 30),

        ElevatedButton(
          onPressed: null,
          child: const Text('Sign in with Microsoft'),
        ),
      ],
    );
  }
}
