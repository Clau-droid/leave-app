import 'package:flutter/material.dart';
import 'home_screen.dart';

class CompanyLoginTab extends StatefulWidget {
  const CompanyLoginTab({super.key});

  @override
  State<CompanyLoginTab> createState() =>
      _CompanyLoginTabState();
}

class _CompanyLoginTabState
    extends State<CompanyLoginTab> {
  final companyNumberController =
      TextEditingController();

  final nicController =
      TextEditingController();

  void signIn() {
    if (companyNumberController.text.isNotEmpty &&
        nicController.text.isNotEmpty) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) =>
              const HomeScreen(),
        ),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content:
              Text('Please fill in all fields'),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Company Number',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w500,
            ),
          ),

          const SizedBox(height: 10),

          TextField(
            controller: companyNumberController,
            decoration: InputDecoration(
              hintText: 'Enter Company Number',
              border: OutlineInputBorder(
                borderRadius:
                    BorderRadius.circular(12),
              ),
            ),
          ),

          const SizedBox(height: 25),

          const Text(
            'NIC',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w500,
            ),
          ),

          const SizedBox(height: 10),

          TextField(
            controller: nicController,
            decoration: InputDecoration(
              hintText: 'Enter NIC',
              border: OutlineInputBorder(
                borderRadius:
                    BorderRadius.circular(12),
              ),
            ),
          ),

          const SizedBox(height: 30),

          SizedBox(
            width: double.infinity,
            height: 55,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor:
                    const Color(0xFF041553),
              ),
              onPressed: signIn,
              child: const Text(
                'Sign In',
                style: TextStyle(
                  color: Colors.white,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
