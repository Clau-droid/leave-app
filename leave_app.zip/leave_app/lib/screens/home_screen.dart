import 'package:flutter/material.dart';
import 'login_screen.dart';
import 'viewbalance_comcode.dart';
import 'apply_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // DRAWER
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            // DRAWER HEADER
            Container(
              color: const Color(0xFF041553),
              child: SafeArea(
                bottom: false,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 15, 20, 15),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Menu', 
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),

                      // CLOSE BUTTON
                      IconButton(
                        icon: const Icon(
                          Icons.close,
                          color: Colors.white,
                        ),
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                      ),
                    ], 
                  ), 
                ), 
              ), 
            ), 

            // view balance icon + naviagtion
            ListTile(
              leading: const Icon(Icons.bar_chart),
              title: const Text('View Balance'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const ViewbalanceComcode(),
                  ),
                );
              },
            ),

            // APPLY LEAVE icon + navigation
            ListTile(
              leading: const Icon(Icons.edit_calendar),
              title: const Text('Apply'),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const ApplyScreen(),
                  ),
                );
              },
            ),

            //logout
            ListTile(
              leading: const Icon(
                Icons.logout,
                color: Colors.red,
              ),
              title: const Text(
                'Sign Out',
                style: TextStyle(
                  color: Colors.red
                ),
              ) ,
              onTap: () {
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const LoginScreen(),
                  ),
                  (route) => false,
                  );
              },
            ),
          ],
        ),
      ),

      // APP BAR
      appBar: AppBar(
        backgroundColor: const Color(0xFF041553),
        title: const Text(
          'Welcome',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        iconTheme: const IconThemeData(
          color: Colors.white,
        ),
      ),

      // main screen
      body: const Center(
        child: Text(
          'Employee Leave Portal',
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}
