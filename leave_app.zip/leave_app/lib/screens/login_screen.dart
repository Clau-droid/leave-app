import 'package:flutter/material.dart';
import 'microsoft_logintab.dart';
import 'company_logintab.dart';

class LoginScreen extends StatelessWidget {
  const LoginScreen({super.key});

// use default tab conroller widget
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2, 
    child: Scaffold(
      backgroundColor: const Color(0xFFf5F7Fa),
      
      body: SafeArea(
        child: Container(
          margin: const EdgeInsets.all(24),
          padding: const EdgeInsets.all(24),

          decoration: BoxDecoration(
            color:Colors.white,
            borderRadius: BorderRadius.circular(20),

            boxShadow: [
              BoxShadow(
                color: Colors.grey.withValues(alpha: 0.15),
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
            ],
          ),

          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'Sign in',
                style: TextStyle(
                  fontSize: 30,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF041553),
                ),
              ),

              const SizedBox(height: 25),

              Container(
                decoration: BoxDecoration(
                  color: Colors.grey.shade200,
                  borderRadius: BorderRadius.circular(12),
                ),
                // setting active/inactive color
                child: const TabBar(
                  indicatorColor: Color(0xFF041553),
                  labelColor: Color(0xFF041553),
                  unselectedLabelColor: Colors.grey,
                  tabs: [
                    Tab(text: 'Microsoft'),
                    Tab(text: 'Company'),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              const Expanded(
                child: TabBarView(
                  children: [
                    MicrosoftLoginTab(),
                    CompanyLoginTab(),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    ),
    );

  }
}