import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';

// leave balance screen
class LeaveBalanceScreen extends StatelessWidget {
  const LeaveBalanceScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FA),

      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),

          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // HEADER
              Row(
                children: [
                  IconButton(
                    icon: const Icon(
                      Icons.arrow_back,
                      color: Colors.black,
                      size: 28,
                    ),
                    onPressed: () {
                      Navigator.pop(context);
                    },
                  ),

                  const Expanded(
                    child: Text(
                      'Leave Balance',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF041553),
                      ),
                    ),
                  ),

                  
                  const SizedBox(width: 48),
                ],
              ),

              const SizedBox(height: 35),

              // hard coded values
              // Casual Leave
              buildLeaveCard(
                title: 'Casual Leave',
                total: 11,
                taken: 1,
                remaining: 10,
              ),

              const SizedBox(height: 35),

              // Sick Leave
              buildLeaveCard(
                title: 'Sick Leave',
                total: 15,
                taken: 5,
                remaining: 10,
              ),

              const SizedBox(height: 35),

              // Vacation Leave
              buildLeaveCard(
                title: 'Vacation Leave',
                total: 22,
                taken: 10,
                remaining: 12,
              ),
            ],
          ),
        ),
      ),
    );
  }

  // card for levae balance

  Widget buildLeaveCard({
    required String title,
    required int total,
    required int taken,
    required int remaining,
  }) {

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),

      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withValues(alpha: 0.15),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),

      child: Column(
        children: [
          // LEAVE TYPE TITLE
          Text(
            title,
            style: const TextStyle(
              fontSize: 21,
              fontWeight: FontWeight.bold,
            ),
          ),

          const SizedBox(height: 20),

          // DONUT CHART + DETAILS using fl_chart
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // DONUT CHART
              SizedBox(
                width: 120,
                height: 120,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    PieChart(
                      PieChartData(
                        sectionsSpace: 0,
                        centerSpaceRadius: 35,
                        startDegreeOffset: -90,
                        sections: [
                          PieChartSectionData(
                            value: remaining.toDouble(),
                            color:Colors.greenAccent,
                            radius:18,
                            title:'',
                          ),
                          PieChartSectionData(
                            value: taken.toDouble(),
                            color: Colors.redAccent,
                            radius: 18,
                            title: '',
                          ),
                        ],
                      ),
                    ),
                     

                    Text(
                      '$remaining',
                      style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(width: 30),

              // DETAILS
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Total: $total',
                    style: const TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w500,
                    ),
                  ),

                  const SizedBox(height: 12),

                  Text(
                    'Taken: $taken',
                    style: const TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w500,
                    ),
                  ),

                  const SizedBox(height: 12),

                  Text(
                    'Remaining: $remaining',
                    style: const TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}
